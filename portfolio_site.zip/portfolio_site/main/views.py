from django.shortcuts import render

def home(request):
    return render(request, 'main/index.html')  # Notice 'main/index.html'

